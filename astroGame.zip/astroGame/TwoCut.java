import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class TwoCut extends World
{

    
    public TwoCut()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 700, 1); 
        prepare();
    }

    
    private void prepare()
    {
        StartButton startButton = new StartButton();
        addObject(startButton,310,550);
        
        GreenfootImage boyImage = new GreenfootImage("astro2.png");//the astronaut image that is drawn;
        getBackground().drawImage(boyImage, 70, 70);

        GreenfootImage bombImage = new GreenfootImage("bomb4.png");//the astronaut image that is drawn;
        getBackground().drawImage(bombImage, 70, 500);
        
        GreenfootImage bombImage1 = new GreenfootImage("bomb4.png");//the astronaut image that is drawn;
        getBackground().drawImage(bombImage1, 510, 500);
        
        GreenfootImage enemyImage = new GreenfootImage("alien5.png");//the astronaut image that is drawn;
        getBackground().drawImage(enemyImage, 270, 600);
    }
}
