import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class LevelTwo extends World
{

    public LevelTwo()
    {

        super(600, 700, 1);
        //resetting all static variables
        Astro.time = 0;
        Astro.timer = 0;
        Astro.timer1 = 0;
        Astro.time1 = 7;
        Astro.gameOn = false;
        Astro.onStep = false;
        Astro.firstTouch = false;
        Astro.faceR = false;
        Astro.faceL = false;
        Astro.powerTouch = false;
        Astro.showPowerText = false;
        Astro.isHit = false;
        Astro.objectAdded = false;
        Astro.startTime = false;

        Enemy.finalMove = false;
        Enemy.setBossLevel = false;

        Enemy.timer2 = 0;
        Enemy.time2 = 0;
        Enemy.speed = 5;
        Enemy.bombSpeed = 0; 
        Enemy.bombMoveText = true;

        prepare();
    }

    private void prepare()
    {
        Astro astro = new Astro();
        addObject(astro,550, 665);
        astro.setImage("astroL.png");
        astro.velocity = 0;

        Enemy enemy = new Enemy();
        addObject(enemy,300,40);

        Bomb bomb = new Bomb();
        addObject(bomb,255,30);
        Step step = new Step();
        addObject(step,450,629);

        Step step2 = new Step();
        addObject(step2,300,450);

        Step step3 = new Step();
        addObject(step3,550,300);

        Step step4 = new Step();
        addObject(step4,357,135);

        Step step5 = new Step();
        addObject(step5,90,301);

        Step step6 = new Step();
        addObject(step6,584,6);
    }
}
