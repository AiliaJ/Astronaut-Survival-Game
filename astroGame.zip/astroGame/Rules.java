import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class Rules extends World
{

    
    public Rules()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 700, 1); 
        prepare();
    }

    
    private void prepare()
    {
        GreenfootImage boyImage = new GreenfootImage("astro2.png");//the astronaut image that is drawn;
        getBackground().drawImage(boyImage, 70, 50);
        Play play = new Play();
        addObject(play,300,600);
    }
}
