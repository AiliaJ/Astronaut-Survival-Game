import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Power here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Power extends Actor
{
    /**
     * Act - do whatever the Power wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // if they lasted 10 seconds give them a five second powerup
        if(Astro.time > 10){
            this.setLocation(this.getX(), this.getY() + 2);
        }
        if(this.getY() > 659){// if the power up has not been used and reaches bottom of world, make it appear again at top
            this.setLocation(Greenfoot.getRandomNumber(600), 0);
        }
    }    
}
