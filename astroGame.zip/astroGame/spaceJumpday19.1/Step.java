import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Step here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Step extends Actor
{
    /**
     * Act - do whatever the Step wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if(Astro.gameOn == true){
            setLocation(this.getX(), this.getY() + 1);
            if(this.isAtEdge()){
                this.setLocation(this.getX() - Greenfoot.getRandomNumber(100), + 20);
                if(this.getX() > 559){
                    setLocation(this.getX() - Greenfoot.getRandomNumber(100), this.getY()+20);

                }
                if(this.getX()< 1){
                    setLocation(this.getX() + Greenfoot.getRandomNumber(100), this.getY() + 15);

                }
            }
            //if(Astro.setLevelTwo == true){
             //   this.setLocation(this.getX(), this.getY() + 1);   
            //}
        }
    }
}    

