import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Astro here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Astro extends Actor
{
    /**
     * Act - do whatever the Astro wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */

    final static int GRAVITY = 1;//for coming back down after jumping
    int velocity = 0;
    static int time = 0;//timer
    static int timer = 0;
    static int timer1 = 0;
    static int time1 = 5;

    static boolean gameOn = false;//if game started
    static boolean onStep = false;//checks to see if astronaut is on a platform
    static boolean firstTouch = false;//checks if astronaut has touched a platform atleast 1 time
    static boolean faceR = false;//astronaut facing right
    static boolean faceL = false;//astronaut facing left
    static boolean powerTouch = false;//checks if a powerup has been touched
    static boolean setLevelTwo = false;

    public void act(){
        if(Greenfoot.isKeyDown("right")){//moving astronaut right
            this.setImage("astro2.png");//makes astronaut face right when moving right
            move(5);
            faceR = true;
            faceL = false;
        }
        if(Greenfoot.isKeyDown("left")){//moving astronaut left
            this.setImage("astroL.png");//makes astronaut face left when moving left        
            move(-5);
            faceL = true;
            faceR = false;
        }
        onStep();

        if((Greenfoot.isKeyDown("space") || Greenfoot.isKeyDown("up")) && (getY() > getWorld().getHeight() - 50 || onStep == true) && velocity == 0 && powerTouch == false){
            //System.out.println("Yes");
            jump();
        }
        fall();
        powerUp();

    }

    public void onStep(){
        Actor step = getOneIntersectingObject(Step.class);
        if(step != null){//checks if the astronaut is on the step
            timer++;// timer to see how long you can last
            if(timer == 60){
                time++;
                timer = 0;
            }
            if(time == 10){
                velocity--;   
            }
            if(time == 6){
                setLevelTwo = true;
                //Greenfoot.setWorld(new LevelTwo());

            }

            getWorld().showText("time: " + time, 100, 300);
            gameOn = true;
            setLocation(this.getX(), step.getY() - 52);
            firstTouch = true;
            onStep = true;

            if(onStep){
                velocity = 0;
            }
        }

    }

    public void fall(){
        setLocation(getX(), getY() + velocity);
        if(getY() > getWorld().getHeight() - 50 && firstTouch == false && powerTouch == false){
            velocity = 0;
            onStep = false;
        }
        else{
            velocity += GRAVITY;
        }
        if(getY() > getWorld().getHeight() - 50 && firstTouch == true){
            firstTouch = false;
            gameOn = false;
            velocity = 0;
            getWorld().showText("You Lose", 300, 350);
            getWorld().showText("You Lasted " + time + " seconds", 300, 370);
            if(faceR == true){//makes the astronaut's hand reach up when it dies
                this.setRotation(270);
            }
            if(faceL == true){//makes the astronaut's hand reach up when it dies
                this.setRotation(90);
            }
            GreenfootImage gImage = new GreenfootImage("g3.png");//shows ghost image after astronaut dies
            getWorld().getBackground().drawImage(gImage, this.getX() -10, this.getY() -100);//location of ghost image

            time = 0;
            Greenfoot.stop();//stops the game

        }
    }

    public void jump(){
        velocity = -20;//"jumping" speed
    }

    public void powerUp(){
        Actor power = getOneIntersectingObject(Power.class);//pointer to power class instances

        if(power != null){//if a power has been touched
            powerTouch = true;
        }
        if(powerTouch == true && (faceL || faceR)){
            timer1++;
            getWorld().removeObject(power);//remove the star from world

            getWorld().showText("timer1: " + timer1, 500, 300);
            getWorld().showText("time1: " + time1, 500, 350);
            if(timer1 == 60){
                time1--;
                timer1 = 0;
            }
            this.setImage("g3.png");
            this.setLocation(this.getX(), 300);

        }
        if(time <= 0){
            power = null;
            powerTouch = false;
            this.setLocation(this.getX(), this.getY());
            if(Greenfoot.isKeyDown("right")){//moving astronaut right
                this.setImage("astro2.png");//makes astronaut face right when moving right
                move(5);
                faceR = true;
                faceL = false;
            }
            if(Greenfoot.isKeyDown("left")){//moving astronaut left
                this.setImage("astroL.png");//makes astronaut face left when moving left        
                move(-5);
                faceL = true;
                faceR = false;
            }

        }
    }
}
