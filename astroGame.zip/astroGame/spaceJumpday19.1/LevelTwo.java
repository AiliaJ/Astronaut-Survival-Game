import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LevelTwo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LevelTwo extends World
{

    /**
     * Constructor for objects of class LevelTwo.
     * 
     */
    public LevelTwo()
    {
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 700, 1);
        if(Astro.setLevelTwo == true){
            Astro astro = new Astro();
            addObject(astro,228, 646 - 70);

            Step step = new Step();
            addObject(step,228,629);

            Step step2 = new Step();
            addObject(step2,394,401);

            Step step3 = new Step();
            addObject(step3,591,236);

            Step step4 = new Step();
            addObject(step4,357,97);

            Step step5 = new Step();
            addObject(step5,90,301);

            Step step6 = new Step();
            addObject(step6,584,6);

            //showText("
        }

    }
}
