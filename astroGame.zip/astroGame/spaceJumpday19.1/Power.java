import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Power here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Power extends Actor
{
    /**
     * Act - do whatever the Power wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if(Astro.time > 5){
            this.setLocation(this.getX(), this.getY() + 2);
        }
        if(this.getY() > 659){
            this.setLocation(Greenfoot.getRandomNumber(600), 0);
            
        }
        
    }    
}
