import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
//import java.awt.Color;
/**
 * Write a description of class NewGame here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class NewGame extends Actor
{
    /**
     * Act - do whatever the NewGame wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if(Greenfoot.mouseClicked(this)){
            
            //getWorld().removeObject(this);
            BackMenu();
            drawSteps();

        }
    }    

    public void drawSteps(){
        GreenfootImage image = new GreenfootImage(100, 10);//creates a filled in recatngle image to be used as steps for jumping
        image.setColor(new Color(255,255,255));//colours for steps
        image.fill();
        setImage(image);
        
    }

    public void BackMenu(){
        //GreenfootImage b2 = new GreenfootImage("blue");
        //getWorld().setBackground(b2);
        Greenfoot.setWorld(new Menu());//to change background of game
        
    }
}
