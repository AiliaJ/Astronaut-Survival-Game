import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.io.*;
import java.awt.Color;
/**
 * Write a description of class How here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class How extends Actor
{
    /**
     * Act - do whatever the How wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    static final Color white = new Color(255,255,255);
    public void act() 
    {
        if(Greenfoot.mouseClicked(this)){
            //Greenfoot.setWorld(new Rules());//to change background of game to screen
            this.setLocation(300, 100);
            Play play = getWorld().getObjects(Play.class).get(0);
            play.setLocation(300, 600);
            showRules();
        }
    }  

    public void showRules(){
        String rules = new String ("Use left and right arrow keys to move left and right");

        getWorld().showText( "Rules:" + rules , 300, 300);
        getWorld().showText("Welcome To Space Jump", 340, 250);
        getWorld().showText("Use the up or space key to jump. hold to double jump", 300, 330);
        getWorld().showText("Don't miss a step and get to the top!", 300, 360);
        getWorld().showText("But beware adventurer for the enemy is near...", 300, 400);

        GreenfootImage boyImage = new GreenfootImage("astro2.png");//the astronaut image that is drawn;
        getWorld().getBackground().drawImage(boyImage, 150, 200);

        //System.out.println("Yes");
    }
}
