import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Screen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Screen extends World
{

    /**
     * Constructor for objects of class Screen.
     * 
     */
    public Screen()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 700, 1); 
        Play.setScreen = true;
        if(Play.setScreen == true){//only add character if the World is "screen"
            Astro astro = new Astro();
            addObject(astro,110,665);

            Power power = new Power();
            addObject(power, 300, 0);   
            power.setLocation(power.getX(), power.getY() + 1);

        }
        // showText("Press left or right arrow key to start", 300, 50);
        Power power = new Power();
        addObject(power, 300, 0);   
        
        Step step = new Step();
        addObject(step,228,629);

        Step step2 = new Step();
        addObject(step2,394,401);

        Step step3 = new Step();
        addObject(step3,591,236);

        Step step4 = new Step();
        addObject(step4,357,97);

        Step step5 = new Step();
        addObject(step5,90,301);

        Step step6 = new Step();
        addObject(step6,584,6);
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {

    }
}

