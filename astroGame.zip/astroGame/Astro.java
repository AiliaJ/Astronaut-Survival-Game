import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Astro extends Actor
{
    final static int GRAVITY = 1;//for coming back down after jumping
    int velocity = 0;
    static int time = 0;//timer
    static int timer = 0;
    static int timer1 = 0;
    static int time1 = 7;

    static boolean gameEnd = false;
    static boolean gameOn = false;//if game started
    static boolean onStep = false;//checks to see if astronaut is on a platform
    static boolean firstTouch = false;//checks if astronaut has touched a platform atleast 1 time
    static boolean faceR = false;//astronaut facing right
    static boolean faceL = false;//astronaut facing left
    static boolean powerTouch = false;//checks if a powerup has been touched
    static boolean setLevelTwo = false;//move to level two world
    static boolean showPowerText = false;
    static boolean startTime = false;

    static boolean isHit = false;//has a bomb touvhed the actor
    static boolean firstMove = false;//checks if already changed levels so that it doesn't change worlds when timer reaches
    static boolean objectAdded = false;//checks if the power has been added

    public void act(){
        getWorld().showText("time: " + time, 100, 100);//show on screen how many seconds the player can last
        if(Greenfoot.isKeyDown("right") && gameEnd == false){//moving astronaut right
            startTime = true;
            this.setImage("astro2.png");//makes astronaut face right when moving right
            move(5);
            faceR = true;
            faceL = false;
            if(setLevelTwo == true){
                startTime = true;
            }
        }
        if(Greenfoot.isKeyDown("left") && gameEnd == false){//moving astronaut left
            startTime = true;
            this.setImage("astroL.png");//makes astronaut face left when moving left        
            move(-5);
            faceL = true;
            faceR = false;
        }
        if(startTime == true){
            timer++;// timer to see how long you can last
            if(timer == 60){
                time++;//time displayed
                timer = 0;
            }
        }
        onStep();
        if((Greenfoot.isKeyDown("space") || Greenfoot.isKeyDown("up")) && (getY() > getWorld().getHeight() - 50 || onStep == true) && (velocity == 0 || velocity ==1) && powerTouch == false && gameEnd == false ){
            jump();//jump only if space or up key is down
        }
        fall();
        powerUp();
        enemyTouch();
    }

    public void onStep(){//check if the actor has touched a step
        Actor step = getOneIntersectingObject(Step.class);

        if(step != null){//checks if the astronaut is on the step
            gameOn = true;
            setLocation(this.getX(), step.getY() - 52);
            firstTouch = true;
            onStep = true;
            if(onStep){
                velocity = 0;
            }
        }
        if(time > 25){
            setLevelTwo = true;//go to next level if timer has recahed this
        }
        if(setLevelTwo == true && firstMove == false && powerTouch == false){
            onStep = false;
            firstTouch = false;
            Greenfoot.setWorld(new TwoCut());
            firstMove = true;
        }
        if(velocity >= 21){//if it gets too fast lower velocity
            velocity = 18;
        }
    }

    public void fall(){
        setLocation(getX(), getY() + velocity);
        if(getY() > getWorld().getHeight() - 50 && firstTouch == false && powerTouch == false){//if they haven't touched a step yet don't die when you hit ground
            velocity = 0;
            onStep = false;
        }
        else{
            velocity += GRAVITY;
        }
        if(getY() > getWorld().getHeight() - 50 && firstTouch == true){//if they have touched a step then die if ground touched
            gameOn = false;
            gameEnd = true;
            velocity = 0;
            getWorld().showText("You Lose", 300, 350);
            getWorld().showText("You Lasted " + time + " seconds", 300, 370);
            if(faceR == true){//makes the astronaut's hand reach up when it dies
                this.setRotation(270);
            }
            if(faceL == true){//makes the astronaut's hand reach up when it dies
                this.setRotation(90);
            }
            GreenfootImage gImage = new GreenfootImage("g3.png");//shows ghost image after astronaut dies
            getWorld().getBackground().drawImage(gImage, this.getX() -10, this.getY() -100);//location of ghost image
            time = 0;
            Enemy.time2 = 0;
            Greenfoot.stop();//stops the game
        }
    }

    public void jump(){
        velocity = -20;//"jumping" speed
    }

    public void powerUp(){
        if(Astro.time > 10 && objectAdded == false){//add the power object if 10 is greater than 10
            getWorld().addObject(new Power(), Greenfoot.getRandomNumber(600), 0);
            objectAdded = true;
        }
        Actor power = getOneIntersectingObject(Power.class);//pointer to power class instances
        if(power != null){//if a power has been touched
            powerTouch = true;
            showPowerText = true;
        }
        if(powerTouch == true && (faceL || faceR)){
            getWorld().showText("Power Up Ends In: " + time1, 300, 220);
            getWorld().showText("Land on a Platform Before Time Runs out ", 300, 200);
            timer1++;
            velocity =0;
            getWorld().removeObject(power);//remove the star from world
            if(timer1 == 60){
                time1--;
                timer1 = 0;
            }
            this.setImage("g3.png");
            this.setLocation(this.getX(), 300);
            if(time1 <= 0){
                showPowerText = false;
                getWorld().showText("", 300, 220);
                getWorld().showText("", 300, 200);
                powerTouch = false;
                this.setLocation(this.getX(), this.getY());
                if(faceR){
                    this.setImage("astro2.png");
                }
                if(faceL){
                    this.setImage("astroL.png");
                }
                objectAdded = false;
                time1 = 0;
            }
        }
    }

    public void enemyTouch(){
        Actor bomb = getOneIntersectingObject(Bomb.class);
        if( bomb!=null && powerTouch == false){//if a bomb has been touched
            firstTouch = false;
            gameOn = false;
            gameEnd = true;
            velocity = 0;
            getWorld().showText("You Lose", 300, 350);
            getWorld().showText("You Lasted " + time + " seconds", 300, 370);
            this.setLocation(this.getX(), 665);
            if(faceR == true){//makes the astronaut's hand reach up when it dies
                this.setRotation(270);
            }
            if(faceL == true){//makes the astronaut's hand reach up when it dies
                this.setRotation(90);
            }
            GreenfootImage gImage = new GreenfootImage("g3.png");//shows ghost image after astronaut dies
            getWorld().getBackground().drawImage(gImage, this.getX() -10, this.getY() -100);//location of ghost image
            Enemy.finalMove = false;
            time = 0;
            Enemy.time2 = 0;
            Greenfoot.stop();//stops the game

        }

    }
}
