import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class BossLevel extends World
{

    public BossLevel()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 700, 1);
        //resetting all static variables
        Enemy.time2 = 0;
        Enemy.timer2 = 0;
        Enemy.speed = 5;
        Enemy.bombSpeed = 0; 
        Enemy.finalMove = false;
        Enemy.setBossLevel = false;

        Astro.setLevelTwo = false;
        Astro.time = 0;
        Astro.timer = 0;
        Astro.timer1 = 0;
        Astro.time1 = 7;
        Astro.gameOn = false;
        Astro.onStep = false;
        Astro.firstTouch = false;
        Astro.time = 0;
        Astro.timer = 0;
        Bomb.time3 = 0;
        Bomb.timer3 =0;
        Bomb.bossBombMove = true;

        Astro.startTime = false;
        prepare();
    }

    private void prepare()
    {
        Enemy enemy = new Enemy();
        addObject(enemy,120,50);

        Bomb bomb2 = new Bomb();
        addObject(bomb2,160,40);

        Astro astro = new Astro();
        addObject(astro,210, 665);
        astro.velocity = 0;

        Step step = new Step();
        addObject(step,51,398);

        Step step2 = new Step();
        addObject(step2,326,598);

        Step step3 = new Step();
        addObject(step3,281,307);

        Step step4 = new Step();
        addObject(step4,130,130);

        Step step5 = new Step();
        addObject(step5,547,132);

        Step step6 = new Step();
        addObject(step6,498,426);

    }
}
