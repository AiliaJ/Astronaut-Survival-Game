import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Step here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Step extends Actor
{
    /**
     * Act - do whatever the Step wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if(Astro.gameOn == true){//if they have touched a step
            setLocation(this.getX(), this.getY() + 1); //start moving the step down
            if(this.isAtEdge()){//if reached the edge of the screen
                this.setLocation(this.getX() - Greenfoot.getRandomNumber(100), + 20);
                if(this.getX() > 559){// if random number is too close to right side eof screen
                    setLocation(this.getX() - Greenfoot.getRandomNumber(100), this.getY()+20);

                }
                if(this.getX()< 1){// if random number is too close to left side of screen
                    setLocation(this.getX() + Greenfoot.getRandomNumber(100), this.getY() + 15);

                }
            }
        }
    }
}    

