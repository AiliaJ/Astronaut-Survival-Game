import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Bomb extends Actor
{

    static int timer3 = 0;
    static int time3 = 0;
    static boolean bossBombMove = true;//variable to show text for specific time
    public void act() 
    {
        if(Enemy.finalMove == true){
            getWorld().showText("time: " + time3, 100, 100);//timer of this world
            getWorld().showText("Missiles Will Start Moving at 3 Seconds" , 330, 100);//timer of this world

            if(Astro.firstTouch == true){
                timer3++;
                if(timer3 == 60){
                    time3++;
                    timer3 = 0;
                }
            }
            if(time3 > 2){
                bossBombMove = false;
                getWorld().showText("" , 330, 100);//timer of this world
                movement();
            }
            if(time3 > 15){
                endGame();//show the end of game screen
            }
        }
    }

    public void movement(){
        Enemy enemy = getWorld().getObjects(Enemy.class).get(0);//pointer to enemy
        this.setLocation(enemy.getX(), this.getY() + 7);//move the bomb
        if(this.getY() > 659){//if bomb reaches bottom of world spawn it at top
            this.setLocation(Greenfoot.getRandomNumber(600), 0);  
            Enemy.bombSpeed++;
        }
        if(Enemy.bombSpeed > 15){//if the bomb's speed is tto high reduce it
            Enemy.bombSpeed = 5 ;   
        }
    }

    public void endGame(){
        Greenfoot.setWorld(new EndGame());//shows the end game world
    }
}
