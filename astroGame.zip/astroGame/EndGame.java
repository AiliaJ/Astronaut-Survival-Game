import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class EndGame extends World
{

    
    public EndGame()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 700, 1);
        prepare();
    }

    public void prepare(){
        NextButton nextButton = new NextButton();
        addObject(nextButton,470, 640);
    }
}
