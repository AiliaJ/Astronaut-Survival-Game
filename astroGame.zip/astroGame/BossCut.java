import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class BossCut extends World
{

    
    public BossCut()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 700, 1); 
        prepare();
    }

    
    private void prepare()
    {

        StartBossButton startBossButton = new StartBossButton();
        addObject(startBossButton,298,520);
       

    }
}
