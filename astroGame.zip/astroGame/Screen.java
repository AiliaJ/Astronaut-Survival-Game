import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Screen extends World
{

    public Screen()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 700, 1); 
//resetting all static variables
        Astro.time = 0;
        Astro.timer = 0;
        Astro.timer1 = 0;
        Astro.time1 = 7;
        Astro.gameOn = false;
        Astro.onStep = false;
        Astro.firstTouch = false;
        Astro.faceR = false;
        Astro.faceL = false;
        Astro.powerTouch = false;
        Astro.setLevelTwo = false;
        Astro.showPowerText = false;
        Astro.firstMove = false;
        Astro.isHit = false;
        Astro.firstMove = false;
        Astro.objectAdded = false;
        Astro.startTime = false;
        Astro.gameEnd = false;

        Enemy.timer2 = 0;
        Enemy.time2 = 0;
        Enemy.speed = 5;
        Enemy.bombSpeed = 0; 
        Enemy.finalMove = false;
        Enemy.setBossLevel = false;
        Enemy.bombMoveText = true;

        Bomb.bossBombMove = true;
        Bomb.timer3 = 0;
        Bomb.time3 = 0;
        prepare();
    }

    private void prepare()
    {
        Astro astro = new Astro();
        addObject(astro,110,665);

        Step step = new Step();
        addObject(step,228,629);

        Step step2 = new Step();
        addObject(step2,394,401);

        Step step3 = new Step();
        addObject(step3,591,236);

        Step step4 = new Step();
        addObject(step4,357,97);

        Step step5 = new Step();
        addObject(step5,90,301);

        Step step6 = new Step();
        addObject(step6,584,6);
    }
}

