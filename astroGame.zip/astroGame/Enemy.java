import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Enemy extends Actor
{
    static int time2 = 0;
    static int timer2 = 0;
    static int speed = 5;
    static int bombSpeed = 0; 

    static boolean setBossLevel = false;
    static boolean finalMove = false;
    static boolean bombMoveText = true;

    public void act() 
    {
        if(Astro.gameEnd == false){
            this.setLocation(this.getX() - speed, this.getY());
        }
        if((Astro.faceR == true || Astro.faceL == true) && Astro.setLevelTwo == true){
            timer2++;
            if(timer2 == 60){
                time2++;
                timer2 = 0;
            }
        }
        getWorld().showText("time: " + time2, 100, 100);
        if(bombMoveText == true){
            getWorld().showText("Missiles Will Start Moving at 3 Seconds", 330, 100);   
        }
        motion();
        lastLevel();
        bombDrop();
    }   

    public void motion(){//movement of enemy
        if(this.getX() >= 555){
            speed*=-1;   
        }
        if(this.getX() <= 5){
            speed*=-1;   
        }
    }

    public void bombDrop(){
        if(Astro.gameOn == true && finalMove == false){//movement of bomb in level Two
            Bomb bomb = getWorld().getObjects(Bomb.class).get(0);
            if(time2 > 3){
                bombMoveText = false;
                getWorld().showText("", 330, 100);   

                bomb.setLocation(bomb.getX(), bomb.getY() + 7);

            }
            if(bomb.getY() > 659){
                bomb.setLocation(Greenfoot.getRandomNumber(600), 0);  
                bombSpeed++;
            }
            if(bombSpeed > 15){
                bombSpeed = 5;   
            }
        }
    }

    public void lastLevel(){
        if(time2 > 20){//if the player lasts 25 seconds go to boss level
            setBossLevel = true;
        }
        if(setBossLevel == true && finalMove == false && Astro.powerTouch == false){
            Astro.onStep = false;
            Astro.firstTouch = false;
            Greenfoot.setWorld(new BossCut());//show the cutscene before boos level starts
        }
    }
}